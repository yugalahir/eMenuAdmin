<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->            <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/chain">
                    <i class="fa fa-chain"></i>
                    <span>Chain</span>
                </a>
            </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/languages">
                    <i class="fa fa-microphone"></i>
                    <span>Languages</span>
                </a>
            </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/outlet">
                    <i class="fa fa-sitemap"></i>
                    <span>Outlet</span>
                </a>
            </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/role">
                    <i class="fa fa-ticket"></i>
                    <span>Role</span>
                </a>
            </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/user">
                    <i class="fa fa-users"></i>
                    <span>User</span>
                </a>
             </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/devices">
                    <i class="fa fa-users"></i>
                    <span>Devices</span>
                </a>
             </li>

            
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/tables">
                    <i class="fa fa-sitemap"></i>
                    <span>Tables</span>
                </a>
            </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/item">
                    <i class="fa fa-ticket"></i>
                    <span>Item</span>
                </a>
            </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/category">
                    <i class="fa fa-ticket"></i>
                    <span>Category</span>
                </a>
                
                
                
            </li>
            
         
            <li>
                <a href="<?php echo base_url();?>index.php/logout">
                    <i class="fa fa-user"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul></div>        
<!-- sidebar menu end-->
    </div>
</aside>