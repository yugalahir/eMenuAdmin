
<!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
        <!-- page start-->

        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    
                    <header class="panel-heading">
                        Manage User Access
                        <span class="tools pull-right">
                            <a href="javascript:;" class="fa fa-chevron-down"></a>
                         </span>
                    </header>
                    <form action="<?php echo base_url();?>index.php/managePrivilage/savePrivilages" method="post">
                    <div class="panel-body">
                        <!-----------Papge Content------------>
                       
                        <!-----------------Prosess bar---------------------------->
                       	<script>
                            function getData(selectedUserType)
                            {
                                if (selectedUserType.length > 0)
                                {
                                    var xmlhttp = new XMLHttpRequest();
                                    xmlhttp.onreadystatechange = function() {
                                        if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
                                        {
                                            var arr =  JSON.parse(xmlhttp.responseText);
                                                    var i=0;
                                                    
                                                    if(arr[0].tablename !="")
                                                    {
                                                            var out = "";
                                                            var checkRead = "";
                                                            var checkAdd = "";
                                                            var checkUpdate = "";
                                                            var checkDelete = "";
                                                            var rChecked ="";
                                                            var aChecked ="";
                                                            var uChecked ="";
                                                            var dChecked ="";
                                                            var btnSave="";
                                                            
                                                            for(i = 0; i < arr.length; i++) 
                                                            {
                                                            rChecked ="";
                                                            
                                                            if(arr[i].read_access == 1){rChecked =" checked ";} 
                                                            checkRead = "<input type='checkbox' value='1'  name='check_"+arr[i].id+"_1'  "+rChecked+">";
                                                            
                                                            
                                                            aChecked ="";
                                                            if(arr[i].add_access == 1){aChecked =" checked ";} 
                                                            checkAdd = "<input type='checkbox'  value='1'   name='check_"+arr[i].id+"_2' "+aChecked+">";
                                                            
                                                            
                                                            uChecked ="";
                                                            if(arr[i].update_access == 1){uChecked =" checked ";} 
                                                            checkUpdate = "<input type='checkbox'  value='1'    name='check_"+arr[i].id+"_3'  "+uChecked+">";
                                                            
                                                            dChecked ="";
                                                            if(arr[i].delete_access == 1){dChecked =" checked ";} 
                                                            checkDelete = "<input type='checkbox'  value='1'    name='check_"+arr[i].id+"_4'  "+dChecked+">";
                                                            
                                                            btnSave = "<button type='sublit' name='btnSave[]' class='btn btn-primary' value='btn_"+arr[i].id+"' onclick='return confirm(\"Confirm Save\")' >Save</button>";
                                                            
                                                            
                                                                out += "<tr style='padding:0px;'><td style='padding:0px;'>" + (i+1) + "</td><td style='padding:0px;'>" + arr[i].tablename +"</td><td style='padding:0px;'>" + checkRead + "</td><td style='padding:0px;'>" + checkAdd +"</td><td style='padding:0px;'>" + checkUpdate+"</td><td style='padding:0px;'>"+checkDelete+"</td><td>"+btnSave+"</td></tr>";
                                                                
                                                            }
                                                            $("#table_body").html("");
                                                            $("#table_body").append(out);
                                                              
                                                     }
                                                  
                                        }
                                    }
                                    xmlhttp.open("GET", "<?php echo base_url(); ?>index.php/managePrivilage/getAccess?user_type=" + selectedUserType, true);
                                    xmlhttp.send();
                                }
                            }
                            
                            
                        </script>
                        
                        <div class='row-fluid'>
                            <div class='col-lg-2'>
                                <div>
                                    <label>Select User Type </label>
                                    <select  class='form-control' onchange="getData(this.value)" >
                                        <option value="">Select User Type</option>
                                             <?php
                                             foreach ($role as $userType)
                                             {?>
                                                <option value="<?=$userType['roleid'];?>"><?=$userType['name'];?></option>
                                                 
                                   <?php     }
                                             ?>
                                        </select>
                                    
                                </div>
                            </div>
                        </div>
                        
                        
                            <table class="table  table-hover general-table">
                                <thead >
                            <tr style="border-bottom-color:#000;">
                                <th style="border-bottom-color:#000;">Sr No</th>
                                <th style="border-bottom-color:#000;">Table Name</th>
                                <th style="border-bottom-color:#000;">Read</th>
                                <th style="border-bottom-color:#000;">Add</th>
                                <th style="border-bottom-color:#000;">Update</th>
                                <th style="border-bottom-color:#000;">Delete</th>
                                <th style="border-bottom-color:#000;">Save</th>
                            </tr>
                            </thead>
                            <tbody id="table_body">
                           
                            </tbody>
                        </table>
                    </form>
                       <!-----------!Papge Content------------>
                       
                    </div>
                </section>
            </div>
        </div>
        <!-- page end-->
        </section>
    </section>
    <!--main content end-->
<!--right sidebar start-->
