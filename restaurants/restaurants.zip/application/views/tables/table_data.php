


<!--sidebar end-->
    <!--main content start-->
    <section id="main-content">
        <section class="wrapper">
        <!-- page start-->

        <div class="row">
            <div class="col-sm-12">
                <section class="panel">
                    
                    <header class="panel-heading">
                        Manage <?php echo $page_title; ?>
                        <span class="tools pull-right">
                            <a href="javascript:;" class="fa fa-chevron-down"></a>
                         </span>
                    </header>
                    <div class="panel-body">
                        <!-----------Papge Content------------>
                        <!-----------------Prosess bar---------------------------->
                       					
                            <?php echo $output; ?>
                        
                       <!-----------!Papge Content------------>
                       
                    </div>
                </section>
            </div>
        </div>
        <!-- page end-->
        </section>
    </section>
    <!--main content end-->
<!--right sidebar start-->
