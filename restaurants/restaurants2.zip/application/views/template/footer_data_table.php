
</section>
<script src="<?php echo base_url();?>assets/bs3/js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo base_url();?>assets/js/jquery.nicescroll.js"></script>

<!-common script init for all pages->
<script src="<?php echo base_url();?>assets/js/scripts.js"></script>


<!-- END JAVASCRIPTS -->


</body>
</html>
