
<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->            <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            
          <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/user">
                    <i class="fa fa-ticket"></i>
                    <span>User</span>
                </a>
            </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/tables">
                    <i class="fa fa-ticket"></i>
                    <span>Tables</span>
                </a>
            </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/category">
                    <i class="fa fa-ticket"></i>
                    <span>Category</span>
                </a>
                
                
                
            </li>
            
            <li>
                <a href="<?php echo base_url();?>index.php/<?=$control_type;?>/categoryItemMapping">
                    <i class="fa fa-ticket"></i>
                    <span>Category Item</span>
                </a>
            </li>
            
            <li>
		<a href="<?php echo base_url();?>index.php/<?=$control_type;?>/item">
                    <i class="fa fa-users"></i>
                    <span>Item</span>
                </a>
            </li>
            
            

            <li>
                <a href="<?php echo base_url();?>index.php/logout">
                    <i class="fa fa-user"></i>
                    <span>Logout</span>
                </a>
            </li>
        </ul></div>        
<!-- sidebar menu end-->
    </div>
</aside>