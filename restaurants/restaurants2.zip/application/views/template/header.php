<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="TABEER AHMAD RIZAVI, KUL BHUSHAN GUPTA">
    <link rel="shortcut icon" href="<?php echo base_url();?>assets/images/header.png">

    <title><?php echo $title; ?></title>

    <!--Core CSS -->
    <link href="<?php echo base_url();?>assets/bs3/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/bootstrap-reset.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/js/bootstrap-datepicker/css/datepicker.css" />
    
    <link rel="stylesheet" href="<?php echo base_url();?>assets/js/data-tables/DT_bootstrap.css" />
    <!-- Custom styles for this template -->
    <link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet">
    <link href="<?php echo base_url();?>assets/css/style-responsive.css" rel="stylesheet" />
    <!------------------------------CHART--------------------------------------->
    <link rel="stylesheet" href="<?php echo base_url();?>assets/amcharts/style.css" type="text/css">
    <script src="<?php echo base_url();?>assets/amcharts/amcharts.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/amcharts/serial.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/amcharts/exporting/amexport.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/amcharts/exporting/rgbcolor.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/amcharts/exporting/canvg.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>assets/amcharts/exporting/filesaver.js" type="text/javascript"></script>
    
    
    
    <!-----------------------------CHART--------------------------------------->
    
</head>
<body>
<section id="container" >
