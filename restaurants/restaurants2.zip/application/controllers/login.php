<?php  defined('BASEPATH') OR exit('No direct script access allowed');
session_start();
class login extends CI_Controller {

	public function index($page = 'login')
	{
		$data['title'] = ucfirst($page); // Capitalize the first letter
		$this->load->view($page, $data);
	}
	
	public function fogetPassword()
        {
              echo "No Email id in user table";
//            $form_data = array('email' => $this->input->post('email'));
//            $this->load->model('user');
//            $userData  = $this->user->getUser($form_data);
//            
//            echo "<pre>";
//            print_r($userData);
           
        }
        
	public function validate_login()
	{
            $form_data = array(
                'username' => $this->input->post('UserName'),
                'password' => $this->input->post('Password')
            );
            $this->load->model('user');
            $userData  = $this->user->getUser($form_data);
            
            
            if($userData!=false)
            {
                $this->load->model('role');
                
		$_SESSION['authorize_user']= $userData['userid'];
                $data=array(
                    'is_logged_in'=>true
                    );
                
                $this->session->set_userdata($userData);
                $this->session->set_userdata($data);
                
                
                $this->load->model('outlet');
                $dataOutlet = $this->outlet->getOutlet(array('outletid'=>$userData['outletid']));
                
                
                $usreRole = $userData['name'];
                
                switch($usreRole)
                {
                    case "Super Admin":
                        $this->session->set_userdata(array('control_type'=>'superAdmin'));
                        redirect('superAdmin'); 
                        break;
                    case "Chain Admin":
                        $this->session->set_userdata(array('control_type'=>'chainAdmin'));
                        $this->session->set_userdata(array('chainid'=>$dataOutlet[0]['chainid']));
                        redirect('chainAdmin'); 
                        break;
                    case "Outlet Admin":
                        $this->session->set_userdata(array('control_type'=>'outletAdmin'));
                        $this->session->set_userdata(array('chainid'=>$dataOutlet[0]['chainid']));
                        redirect('outletAdmin'); 
                        break;
                    case "Manager":
                        $this->session->set_userdata(array('control_type'=>'manager'));
                        $this->session->set_userdata(array('chainid'=>$dataOutlet[0]['chainid']));
                        redirect('manager'); 
                        break;
                    case "Chef":
                        $this->session->set_userdata(array('control_type'=>'chef'));
                        $this->session->set_userdata(array('chainid'=>$dataOutlet[0]['chainid']));
                        redirect('chef'); 
                        break;
                    case "Waiter":
                        $this->session->set_userdata(array('control_type'=>'waiter'));
                        $this->session->set_userdata(array('chainid'=>$dataOutlet[0]['chainid']));
                        redirect('waiter'); 
                        break;
                    default :
                        echo "User Role Not Associated With Controll";
                }
                    
		//redirect(ucfirst($resultData['designation']));
            }
            else
            {
                $page="login";
                $data['title'] = ucfirst($page); // Capitalize the first letter
                $data['message'] = "Invalid login";
                $this->load->view($page, $data);
            }
	}
}
